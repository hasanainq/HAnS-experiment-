package Hive;

public class DBCredentials {
    public static String url = "jdbc:mysql://localhost:3306/Hive";
    public static String user = "root";
    public static String pass = "12345";
}
