import Hive.ConfigDB;

public class Main {
    public static void main(String[] args) {
        ConfigDB c = new ConfigDB();
        LoginForm f = new LoginForm();
    }
}